/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.atividade01;

/**
 *
 * @author sala302b
 */
public class Atividade01 {

    public static void main(String[] args) {
        System.out.println("Ola Turma!!!");
        
        System.out.println("1,2,3");
        
        
    }
}
